#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright: Anthony Aardvark. All rights reserved.
 * Date: 14 May 2016
**/

int main(int argc, char *argv[]) {
  cout << "Hello, world." << endl;
  cout << "My name is Anthony Aardvark." << endl;

  return 0;
}
