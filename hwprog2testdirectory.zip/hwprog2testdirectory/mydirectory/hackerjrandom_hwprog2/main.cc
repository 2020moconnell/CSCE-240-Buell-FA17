#include "main.h"

/****************************************************************
 * Main program for Homework 2.
 *
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Used with permission and modified by: Jane Random Hacker
 * Date: 2 August 2017
 *
**/

int main(int argc, char *argv[]) {

  cout << "MAX VALUE IS " << max_distance << endl;
  cout << "MIN VALUE IS " << min_distance << endl;
  return 0;
}

