/****************************************************************
 * Header file for the 'XMLItem' class to contain one XML item.
 *
 * Documentation for this code is in the implementation file.
 *
 * Author/copyright:  Duncan Buell
 * Used with permission and modified by: Jane Random Hacker
 * Date: 2 August 2017
**/

#ifndef XMLITEM_H
#define XMLITEM_H

#include <iostream>
using namespace std;

class XMLItem {
  public:
    XMLItem();
    XMLItem(int level, string item, string which);
    virtual ~XMLItem();

  private:
};

#endif
